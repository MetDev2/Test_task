#import sqlite3'
import pytest
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities


@pytest.yield_fixture(scope="session")
def site_load():
    driver = webdriver.Remote(
        command_executor='http://127.0.0.1:4444/wd/hub',
        desired_capabilities=DesiredCapabilities.FIREFOX)
    yield driver
    driver.close()


#@pytest.fixture(scope="function")
# def db():
#    conn = sqlite3.connect('%Название базы данных%')
#    cursor = conn.cursor()
#    cursor.executescript("""DELETE FROM %Название таблицы%
#    WHERE username != '11';
#    VACUUM
#    """)
#    conn.close()


@pytest.fixture(scope="function", params=[
    ('a' * 151, 'meteliza.evgeniy.98@mail.ru', 'sjltr985'),
    ('&ace', 'meteliza.evgeniy.98.work@mail.ru', 'sjltr985'),
    ('abcde', 'meteliza.evgeniy.98.work@mail..ru', 'sjltr985'),
    ('abcdef', 'meteliza.evgeniy.98.work@mail.ru', '123456789')], ids=[
    "len(username) > 151", "username with spec simbol",
    "invalid email", "easy numeric password"])
def negative_test_data(request):
    return request.param
