from selenium.webdriver.common.by import By


class PytonzLocators:
    PYTHONZ_LOGINPAGE_BUTTON = (By.XPATH, "//a[@href = '/login/']")
    PYTHONZ_LOGOUT_DROPDOWN = (By.ID, 'navitem-profile')
    PYTHONZ_LOGOUT_BUTTON = (By.XPATH, "//a[@href = '/logout/']")


class PytonzLogPageLocators:
    PYTHONZ_REGISTRATION_USERNAME = (By.XPATH, '//input[@placeholder="Имя пользователя"]')
    PYTHONZ_REGISTRATION_EMAIL = (By.XPATH, '//input[@placeholder="Адрес электронной почты"]')
    PYTHONZ_REGISTRATION_PASSWORD = (By.NAME, "password1")
    PYTHONZ_REGISTRATION_BUTTON = (By.XPATH, '//input[@value="Зарегистрироваться"]')
    PYTHONZ_LOGIN_USERNAME = (By.XPATH, '//input[@placeholder="Имя пользователя / Адрес электронной почты"]')
    PYTHONZ_LOGIN_PASSWORD = (By.NAME, "password")
    PYTHONZ_LOGIN_BUTTON = (By.XPATH, '//input[@value="Войти"]')
