import pytest
from page import LogPage


@pytest.yield_fixture(scope='module')
def page_object(site_load):
    page = LogPage(site_load)
    page.go_to_site()
    yield page


def test_negative(page_object, negative_test_data):
    page = page_object
    (username, email, password) = negative_test_data
    page.go_to_logpage()
    page.registration(username, email, password)
    assert not page.successful_registration(), 'Invalid data'


def test_valid_reg(page_object):
    page = page_object
    page.go_to_logpage()
    page.registration('Шiv1@.+-_' + 'b' * 141, 'meteliza.evgeniy.98@mail.ru', 'sjltr985')
    assert page.successful_registration(), 'Unsuccessful registration'


def test_reg_existing_user(page_object):
    page = page_object
    page.go_to_logpage()
    page.registration('Шiv1@.+-_' + 'b' * 141, 'evgeniy.meteliza.98@mail.ru', 'sjltr985')
    assert not page.successful_registration(), 'This username must be already taken'


def test_reg_existing_email(page_object):
    page = page_object
    page.go_to_logpage()
    page.registration('Someuser1', 'meteliza.evgeniy.98@mail.ru', 'sjltr985')
    assert not page.successful_registration(), 'This email must be already taken'

    
def test_valid_login_with_username(page_object):
    page = page_object
    page.go_to_logpage()
    page.login('qwerty123456', username='11')
    assert page.successful_login(), 'Unsuccessful login'
    page.logout()
    
    
def test_valid_login_with_email(page_object):
    page = page_object
    page.go_to_logpage()
    page.login('qwerty123456', email='meteliza.evgeniy.98.work@mail.ru')
    assert page.successful_login(), 'Unsuccessful login'
    page.logout()
