from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from locators import PytonzLocators, PytonzLogPageLocators


class BasePage:

    def __init__(self, driver):
        self.driver = driver
#       self.base_url = 'http://localhost:8000/'
        self.base_url = 'https://pythonz.net/'

    def go_to_site(self):
        return self.driver.get(self.base_url)

    def send_text(self, value, locator):
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located(locator),
                                             message=f"Can't find element by locators {locator}").send_keys(value)

    def click_button(self, locator):
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located(locator),
                                             message=f"Can't find element by locator {locator}").click()


class LogPage(BasePage):

    def go_to_logpage(self):
        self.click_button(PytonzLocators.PYTHONZ_LOGINPAGE_BUTTON)

    def is_title_matches(self):
        return "pythonz" in self.driver.title

    def registration(self, username, email, password):
        self.send_text(username, PytonzLogPageLocators.PYTHONZ_REGISTRATION_USERNAME)
        self.send_text(email, PytonzLogPageLocators.PYTHONZ_REGISTRATION_EMAIL)
        self.send_text(password, PytonzLogPageLocators.PYTHONZ_REGISTRATION_PASSWORD)
        self.click_button(PytonzLogPageLocators.PYTHONZ_REGISTRATION_BUTTON)

    def login(self, password, *, email=None, username=None):
        if email is None:
            self.send_text(username, PytonzLogPageLocators.PYTHONZ_LOGIN_USERNAME)
        elif username is None:
            self.send_text(email, PytonzLogPageLocators.PYTHONZ_LOGIN_USERNAME)
        self.send_text(password, PytonzLogPageLocators.PYTHONZ_LOGIN_PASSWORD)
        self.click_button(PytonzLogPageLocators.PYTHONZ_LOGIN_BUTTON)

    def logout(self):
        self.click_button(PytonzLocators.PYTHONZ_LOGOUT_DROPDOWN)
        self.click_button(PytonzLocators.PYTHONZ_LOGOUT_BUTTON)

    def successful_registration(self):
        return 'Поздравляем! Процесс регистрации практически завершён.' in self.driver.page_source

    def successful_login(self):
        return "Пожалуйста, введите правильные имя пользователя и пароль." not in self.driver.page_source
